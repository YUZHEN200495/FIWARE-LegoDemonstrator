/// <reference types="vite/client" />
declare const ENDPOINT: string